from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
import random
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.contrib.auth.tokens import default_token_generator
from django.conf import settings
from .forms import CustomUserCreationForm, CustomPasswordChangeForm, UserProfileForm


def register(request):
    """
    Handle user registration.

    If the request is POST, process the registration form. If valid,
    save the user and log them in, then redirect to the login page.
    Otherwise, render the registration form.
    """
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful! You are now logged in.')
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})


def logout_view(request):
    """
    Log out the user and redirect to the store page.
    """
    logout(request)
    return redirect('store')


def generate_otp():
    """
    Generate a random 6-digit OTP.

    Returns:
        str: A random OTP as a string.
    """
    return str(random.randint(100000, 999999))


def login_view(request):
    """
    Handle user login.

    If the request is POST, validate the login form and generate an OTP
    if valid. Redirect to OTP verification. Otherwise, render the login form.
    """
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            # Generate OTP
            otp = generate_otp()
            print("Generated OTP:", otp)  # Replace with a proper OTP delivery method in production
            request.session['otp'] = otp
            request.session['username'] = user.username
            request.session['password'] = request.POST['password']
            messages.success(request, "An OTP has been sent on your console!")
            return redirect('verify-otp')

    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})


@login_required
def edit_profile(request):
    user = request.user

    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = UserProfileForm(instance=user)

    return render(request, 'accounts/edit_profile.html', {'form': form})


@login_required
def get_profile(request):
    return render(request, 'accounts/profile.html')


def verify_otp(request):
    """
    Verify the OTP entered by the user.

    If the OTP is valid, authenticate the user and log them in.
    Otherwise, show an error message. Redirect authenticated users to the store.
    """
    if request.user.is_authenticated:
        return redirect('store')

    if 'otp' not in request.session:
        return redirect('store')

    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')

        if entered_otp == stored_otp:
            # OTP matched, proceed with login
            uname = request.session.get('username')
            upass = request.session.get('password')
            user = authenticate(username=uname, password=upass)

            if user is not None:
                login(request, user)
                messages.success(request, "Successfully logged in!")
                return redirect('store')
            else:
                messages.error(request, "Authentication failed. User not found.")
        else:
            messages.error(request, "Invalid OTP. Please try again.")

    return render(request, 'accounts/verify_otp.html')


def force_str(s, encoding='utf-8', strings_only=False, errors='strict'):
    """
    Converts a bytestring or object to a string, ensuring proper encoding.

    Args:
        s (str or bytes): The input to convert.
        encoding (str): The encoding to use for bytes.
        strings_only (bool): If True, only convert strings.
        errors (str): Error handling scheme.

    Returns:
        str: The converted string.
    """
    if isinstance(s, bytes):
        return s.decode(encoding, errors)
    elif strings_only and isinstance(s, (list, tuple)):
        return [force_str(item, encoding, strings_only, errors) for item in s]
    return s


def forgot_password(request):
    """
    Handle password reset requests.

    If the request is POST, attempt to retrieve the user by email and send
    a password reset link. If the email is not found, display an error message.
    Otherwise, render the password reset form.
    """
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))

            # Update the reset link with your specified URL
            reset_link = f"http://localhost:8000/reset-password/{uid}/{token}/"

            # Send email with the password reset link
            send_mail(
                'Password Reset Request',
                render_to_string('accounts/password_reset_email.html', {
                    'reset_link': reset_link,
                }),
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            return redirect('password_reset_done')  # Redirect to a confirmation page
        except User.DoesNotExist:
            messages.error(request, 'Email not found')

    return render(request, 'accounts/forgot_password.html')


def reset_password(request, uidb64, token):
    """
    Handle password reset using the token and user ID.

    Validate the token and user ID, and if valid, allow the user to set a new password.
    If the passwords do not match, show an error message.
    """
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)

        if request.method == 'POST':
            new_password = request.POST.get('new_password')
            new_password_confirm = request.POST.get('new_password_confirm')
            if new_password == new_password_confirm:
                user.set_password(new_password)
                user.save()
                messages.success(request, 'Your password has been reset successfully!')
                return redirect('login')
            else:
                messages.error(request, 'Passwords do not match')

        return render(request, 'accounts/reset_password.html', {'user': user, 'uidb64': uidb64, 'token': token})

    except (TypeError, ValueError, OverflowError, User.DoesNotExist) as e:
        messages.error(request, f'Invalid reset link: {str(e)}')
        return redirect('login')


def password_reset_done_view(request):
    """
    Display a confirmation page after a password reset request.
    """
    return render(request, 'accounts/password_reset_done.html')


@login_required
def change_password(request):
    """
    Handle changing the user's password.

    If the request is POST, validate the password change form and update the password.
    Otherwise, render the change password form.
    """
    if request.method == 'POST':
        form = CustomPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('login')
    else:
        form = CustomPasswordChangeForm(request.user)

    return render(request, 'accounts/change_password.html', {'form': form})
